<?php

namespace App\Services\Auth;

class File
{
}
