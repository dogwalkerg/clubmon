<?php

namespace App\Models;

/**
 * EmailVerify Model
 */

class EmailVerify extends Model
{
    protected $connection = "default";
    protected $table = "email_verify";
}
