<?php
/* Smarty version 3.1.34-dev-5, created on 2019-06-09 11:07:27
  from '/home/wwwroot/hkk.flexispy.tk/resources/views/material/auth/register.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-5',
  'unifunc' => 'content_5cfc77ef416fb5_89517411',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0dd60f558cf3320ddf1b5400e92b53be8b0096a9' => 
    array (
      0 => '/home/wwwroot/hkk.flexispy.tk/resources/views/material/auth/register.tpl',
      1 => 1560049621,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:reg_tos.tpl' => 1,
    'file:email_nrcy.tpl' => 1,
  ),
),false)) {
function content_5cfc77ef416fb5_89517411 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset=UTF-8"UTF-8">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<meta content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" name="viewport">
	<meta name="theme-color" content="#3f51b5">
	<title>ShadoWingy官网</title>

	<!-- css -->
	<!--<link href="/theme/material/css/base.css" rel="stylesheet">
	<link href="/theme/material/css/project.css" rel="stylesheet">
	<link href="//fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
     -->
     <link href="../assets2/css/bootstrap.min.css" tppabs="/assets2/css/bootstrap.min.css" rel="stylesheet">
  	<link href="../assets2/css/material-dash.css" tppabs="/assets2/css/material-dash.css" rel="stylesheet">
   
    <link rel="stylesheet" href="../assets2/css/animate.min.css" tppabs="/assets2/css/animate.min.css">
 
  
    <link href="../assets2/css/sweetalert.css" tppabs="/assets2/css/sweetalert.css" rel="stylesheet">
    <?php echo '<script'; ?>
 type="text/javascript" src="../assets2/js/sweetalert.min.js" tppabs="/assets2/js/sweetalert.min.js"><?php echo '</script'; ?>
>
  
   <link href="../../fonts.googleapis.com/icon-family=Material+Icons.css" tppabs="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	
	<!-- favicon -->
  	<link rel="shortcut icon" href="/theme/material/images/users/favicon.png" type="image/x-icon" />
	<!-- ... -->
</head>

 <style>
@import url("../assets2/css/font-awesome.min.css")/*tpa=/assets2/css/font-awesome.min.css*//*tpa=/assets2/css/font-awesome.min.css*/;
   
@font-face { 
	font-family: title-speed;
	src: url("../fonts/LobsterTwo-Regular.otf")/*tpa=fonts/LobsterTwo-Regular.otf*//*tpa=fonts/LobsterTwo-Regular.otf*/;
} 
   
.navbar-brand{
  font-family: title-speed;
  font-size: 1.2rem;
  font-weight: 500;
  
 }

   
   
</style>
  


<body class="off-canvas-sidebar">

<nav class="navbar navbar-primary navbar-transparent navbar-absolute">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand animated swing" href="index" >ShadoWingy官网</a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href="/" >
                      
                      <i class="fa fa-home" aria-hidden="true"></i>   首页
                    </a>
                </li>
                <li class="active">
                    <a href="/auth/register" >
                        <i class="fa fa-user-plus" aria-hidden="true"></i> 注册
                    </a>
                </li>
                <li class="">
                    <a href="/auth/login" >
                        <i class="fa fa-paper-plane" aria-hidden="true"></i> 登录
                    </a>
                </li>
                <li class="">
                    <a href="/auth/login" >
                        <i class="fa fa-cloud-download" aria-hidden="true"></i> 下载
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="wrapper wrapper-full-page">
    <div class="full-page register-page" filter-color="black" data-image="https://img.xjh.me/random_img.php?type=bg&ctype=nature&return=302">
        <!--迷改 bg
        <div class="full-page register-page" filter-color="black" data-image="/img/register.jpeg">
        -->
        <div style="display:none;"><img src="<c:url value='/images/mimi.jpg'/>"  /></div>
                    <div class="container">
                <div class="row">
                    <div class="col-md-10 col-md-offset-1">
                        <div class="card card-signup  animated slideInRight">
                            <h2 class="card-title text-center">Register</h2>
                            <div class="row">
                                <div class="col-md-5 col-md-offset-1">
                                    <div class="card-content">
                                        <div class="info info-horizontal">
                                            <div class="icon icon-rose">
                                                <i class="fa fa-gamepad" aria-hidden="true"></i>
                                            </div>
                                            <div class="description">
                                                <h4 class="info-title">游戏</h4>
                                                <p class="description">
                                                    提供绝地求生，战地，彩虹六号，黑沙等热门游戏加速服务，无论是PC还是PS4, XBox平台均可使用
                                                </p>
                                            </div>
                                        </div>
                                        <div class="info info-horizontal">
                                            <div class="icon icon-primary">
                                                <i class="fa fa-youtube-square" aria-hidden="true"></i>
                                            </div>
                                            <div class="description">
                                                <h4 class="info-title">娱乐</h4>
                                                <p class="description">
                                                    多条高速线路，可观看油管4k视频，速度快，无缓冲
                                                </p>
                                            </div>
                                        </div>
                                        <div class="info info-horizontal">
                                            <div class="icon icon-info">
                                                <i class="fa fa-graduation-cap" aria-hidden="true"></i>
                                            </div>
                                            <div class="description">
                                                <h4 class="info-title">学习</h4>
                                                <p class="description">
                                                    为开发学习助力，可用于python, java, Android, IOS, js, node, php等开发文档的搜索与使用
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="social text-center">
                                        <button class="btn btn-just-icon btn-round btn-twitter">
                                            <i class="fa fa-twitter"></i>
                                        </button>
                                        <button class="btn btn-just-icon btn-round btn-dribbble">
                                            <i class="fa fa-dribbble"></i>
                                        </button>
                                        <button class="btn btn-just-icon btn-round btn-facebook">
                                            <i class="fa fa-facebook"> </i>
                                        </button>
                                        <button class="btn btn-just-icon btn-round btn-facebook">
                                            <i class="fa fa-google"> </i>
                                        </button>
                                        
                                    </div>
                                    <form class="form" method="" action="">
                                        <div class="card-content">
 <div class="input-group">
<span class="input-group-addon">
<i class="fa fa-github-alt" aria-hidden="true"></i>
</span>
<div class="form-group is-empty"><input placeholder="昵称" id="name" class="form-control" 　type="text"><span class="material-input"></span><span class="material-input"></span></div>
</div>                                           

                                          <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                                </span>
                                                <div class="form-group is-empty"><input placeholder="邮箱"  id="email" class="form-control"　type="text"><span class="material-input"></span></div>
                                            </div>
                                          
                                                                                     
                                          
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-lock" aria-hidden="true"></i>
                                                </span>
                                                <div class="form-group is-empty"><input placeholder="密码"  id="passwd" class="form-control" type="password"><span class="material-input"></span></div>
                                            </div>
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-lock" aria-hidden="true"></i>
                                                </span>
                                                <div class="form-group is-empty"><input placeholder="重复密码" id="repasswd" class="form-control" type="password"><span class="material-input"></span></div>
                                            </div>
                                          
                                             
                                            <div class="input-group" style='display:none;'>
                                                <span class="input-group-addon">
                                                    <i class="fa fa-envira" aria-hidden="true"></i>
                                                </span>
                                                <div class="form-group is-empty"><input placeholder="邀请码" id="code" class="form-control" type="text" value="" readonly="readonly" ><span class="material-input"></span></div>
                                            	<div style="font-size:0.7rem;color:black;padding:20px 0px 0px 10px;">邀请码已失效，<br/>但您仍然可以继续注册。</div>
                                            </div>
                                                                                    

                                            <!-- If you want to add a checkbox to this form, uncomment this code -->
                                          
                                           
                                        </div>
                                        <div class="footer text-center">
                                          <button class="btn btn-primary btn-round" id="reg" type="button">
                                        <i class="fa fa-heart" aria-hidden="true"></i> 注册
                                        <div class="ripple-container"></div></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <div class="full-page-background" style="background-image: url(https://img.xjh.me/random_img.php?type=bg&ctype=nature&return=302) "></div></div>
</div>



  
  
	<div class="authpage auth-reg">
			<div class="container">
				<section class="content-inner">
					<div class="auth-main auth-row">

						<?php if ($_smarty_tpl->tpl_vars['config']->value['register_mode'] != 'close') {?>
						


						<?php if ($_smarty_tpl->tpl_vars['config']->value['register_mode'] == 'invite') {?>
						<div class="rowtocol">
							<div class="auth-row">
								<div class="form-group form-group-label">
									<label class="floating-label" for="code">邀请码(必填)</label>
									<input class="form-control maxwidth-auth" id="code" type="text">
								</div>
							</div>
						</div>
						<?php }?>
						<?php if ($_smarty_tpl->tpl_vars['enable_email_verify']->value == 'true') {?>
						<div class="rowtocol">
							<div class="rowtocol">
								<div class="form-group form-group-label">
									<label class="floating-label" for="email_code">邮箱验证码</label>
									<input class="form-control maxwidth-auth" id="email_code" type="text" onKeypress="javascript:if(event.keyCode == 32)event.returnValue = false;">
								</div>
							</div>
							<div class="rowtocol">
								<div class="form-group form-group-label">
									<button id="email_verify" class="btn-reg btn btn-block btn-brand-accent waves-attach waves-light">获取验证码</button>
									<a href="" onclick="return false;" data-toggle='modal' data-target='#email_nrcy_modal'
										class="auth-help-reg">收不到验证码？</a>
								</div>
							</div>
						</div>
						<?php }?>
		
						<?php if ($_smarty_tpl->tpl_vars['geetest_html']->value != null) {?>
						<div class="rowtocol">
							<div class="form-group form-group-label">
								<div id="embed-captcha"></div>
							</div>
						</div>
						<?php }?>
						<?php if ($_smarty_tpl->tpl_vars['recaptcha_sitekey']->value != null) {?>
                            <div class="form-group form-group-label">
                                <div class="row">
                                    <div align="center" class="g-recaptcha" data-sitekey="<?php echo $_smarty_tpl->tpl_vars['recaptcha_sitekey']->value;?>
"></div>
                                </div>
                            </div>
                        <?php }?>

						<div class="rowtocol">
							<div class="btn-auth auth-row">
								<button id="tos" type="submit" class=""></button>
							</div>
						</div>
		
						<?php } else { ?>
						<div class="form-group">
							<p><?php echo $_smarty_tpl->tpl_vars['config']->value["appName"];?>
 已停止新用户注册，请联系网站管理员</p>
						</div>
						<?php }?>

					</div>
				</section>

			</div>
		</div>
		
		<div aria-hidden="true" class="modal modal-va-middle fade" id="tos_modal" role="dialog" tabindex="-1">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-heading">
						<h2 class="modal-title">注册 TOS</h2>
					</div>
					<div class="modal-inner">
						<?php $_smarty_tpl->_subTemplateRender('file:reg_tos.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
					</div>
					<div class="modal-footer">
						<p class="text-right"><button class="btn btn-flat btn-brand-accent waves-attach waves-effect"
								data-dismiss="modal" type="button" id="cancel">我不同意</button>
							<button class="btn btn-flat btn-brand-accent waves-attach waves-effect" data-dismiss="modal" id="reg"
								type="button">我同意</button>
						</p>
					</div>
				</div>
			</div>
		</div>
		
		<div aria-hidden="true" class="modal modal-va-middle fade" id="email_nrcy_modal" role="dialog" tabindex="-1">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-heading">
						<h2 class="modal-title">收不到验证码？</h2>
					</div>
					<div class="modal-inner">
						<?php $_smarty_tpl->_subTemplateRender('file:email_nrcy.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
					</div>
					<div class="modal-footer">
						<p class="text-right">
							<button class="btn btn-flat btn-brand-accent waves-attach waves-effect" data-dismiss="modal" type="button">我知道了</button>
						</p>
					</div>
				</div>
			</div>
		</div>

<div class="tiphidden"></div>

<div aria-hidden="true" class="modal modal-va-middle fade" id="result" role="dialog" tabindex="-1">
	<div class="modal-dialog modal-xs">
		<div class="modal-content">
			<div class="modal-inner">
				<p class="h5 margin-top-sm text-black-hint" id="msg"></p>
			</div>
			<div class="modal-footer">
				<p class="text-right"><button class="btn btn-flat btn-brand-accent waves-attach" data-dismiss="modal" type="button" id="result_ok">知道了</button></p>
			</div>
		</div>
	</div>
</div>


	<!-- js -->
	<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/jquery@2.2.1"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="/theme/material/js/base.min.js"><?php echo '</script'; ?>
>

</body>
</html>

  <?php echo '<script'; ?>
 type="text/javascript" src="../js/jquery-2.2.1.min.js" tppabs="js/jquery-2.2.1.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="../assets2/js/love.js" tppabs="/assets2/js/love.js"><?php echo '</script'; ?>
>

<?php if ($_smarty_tpl->tpl_vars['config']->value['register_mode'] != 'close') {
echo '<script'; ?>
>
    $(document).ready(function(){
        function register(){
          code = $("#code").val();
    	<?php if ($_smarty_tpl->tpl_vars['config']->value['register_mode'] != 'invite') {?>
           code = 0;
           if ((getCookie('code'))!=''){
           code = getCookie('code');
          }
	    <?php }?>
			document.getElementById("tos").disabled = true;

            $.ajax({
                type:"POST",
                url:"/auth/register",
                dataType:"json",
                data:{
                    email: $("#email").val(),
                    name: $("#name").val(),
                    passwd: $("#passwd").val(),
                    repasswd: $("#repasswd").val(),
					wechat: $("#email").val(),
					imtype: "2",
					code:code<?php if ($_smarty_tpl->tpl_vars['enable_email_verify']->value == 'true') {?>,
					emailcode: $("#email_code").val()<?php }
if ($_smarty_tpl->tpl_vars['geetest_html']->value != null) {?>,
					geetest_challenge: validate.geetest_challenge,
                    geetest_validate: validate.geetest_validate,
                    geetest_seccode: validate.geetest_seccode
					<?php }?>
                },
                success:function(data){
                    if(data.ret == 1){
                        $("#result").modal();
                        $("#msg").html(data.msg);
                        window.setTimeout("location.href='/auth/login'", <?php echo $_smarty_tpl->tpl_vars['config']->value['jump_delay'];?>
);
                    }else{
                        $("#result").modal();
                        $("#msg").html(data.msg);
                        setCookie('code','',0);
                        $("#code").val(getCookie('code'));
						document.getElementById("tos").disabled = false;
						<?php if ($_smarty_tpl->tpl_vars['geetest_html']->value != null) {?>
						captcha.refresh();
						<?php }?>
                    }
                },
                error:function(jqXHR){
			$("#msg-error").hide(10);
			$("#msg-error").show(100);
			$("#msg-error-p").html("发生错误："+jqXHR.status);
			document.getElementById("tos").disabled = false;
			<?php if ($_smarty_tpl->tpl_vars['geetest_html']->value != null) {?>
			captcha.refresh();
			<?php }?>
                }
            });
        }
        $("html").keydown(function(event){
            if(event.keyCode==13){
                $("#tos_modal").modal();
            }
        });

		<?php if ($_smarty_tpl->tpl_vars['geetest_html']->value != null) {?>
		$('div.modal').on('shown.bs.modal', function() {
			$("div.gt_slider_knob").hide();
		});


		$('div.modal').on('hidden.bs.modal', function() {
			$("div.gt_slider_knob").show();
		});


		<?php }?>

		$("#reg").click(function(){
            register();
        });

		$("#tos").click(function(){
			<?php if ($_smarty_tpl->tpl_vars['geetest_html']->value != null) {?>
			if(typeof validate == 'undefined')
			{
				$("#result").modal();
                $("#msg").html("请滑动验证码来完成验证。");
				return;
			}

			if (!validate) {
				$("#result").modal();
                $("#msg").html("请滑动验证码来完成验证。");
				return;
			}

			<?php }?>
            $("#tos_modal").modal();
        });
    })
<?php echo '</script'; ?>
>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['enable_email_verify']->value == 'true') {
echo '<script'; ?>
>
var wait=60;
function time(o) {
		if (wait == 0) {
			o.removeAttr("disabled");
			o.text("获取验证码");
			wait = 60;
		} else {
			o.attr("disabled","disabled");
			o.text("重新发送(" + wait + ")");
			wait--;
			setTimeout(function() {
				time(o)
			},
			1000)
		}
	}



    $(document).ready(function () {
        $("#email_verify").click(function () {
			time($("#email_verify"));

            $.ajax({
                type: "POST",
                url: "send",
                dataType: "json",
                data: {
                    email: $("#email").val()
                },
                success: function (data) {
                    if (data.ret) {
                        $("#result").modal();
			$("#msg").html(data.msg);

                    } else {
                        $("#result").modal();
			$("#msg").html(data.msg);
                    }
                },
                error: function (jqXHR) {
                    $("#result").modal();
			$("#msg").html(data.msg+"     出现了一些错误。");
                }
            })
        })
    })
<?php echo '</script'; ?>
>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['geetest_html']->value != null) {
echo '<script'; ?>
>
	var handlerEmbed = function (captchaObj) {
        // 将验证码加到id为captcha的元素里

		captchaObj.onSuccess(function () {
		    validate = captchaObj.getValidate();
		});

		captchaObj.appendTo("#embed-captcha");

		captcha = captchaObj;
		// 更多接口参考：http://www.geetest.com/install/sections/idx-client-sdk.html
    };

	initGeetest({
		gt: "<?php echo $_smarty_tpl->tpl_vars['geetest_html']->value->gt;?>
",
		challenge: "<?php echo $_smarty_tpl->tpl_vars['geetest_html']->value->challenge;?>
",
		product: "embed", // 产品形式，包括：float，embed，popup。注意只对PC版验证码有效
		offline: <?php if ($_smarty_tpl->tpl_vars['geetest_html']->value->success) {?>0<?php } else { ?>1<?php }?> // 表示用户后台检测极验服务器是否宕机，与SDK配合，用户一般不需要关注
	}, handlerEmbed);
<?php echo '</script'; ?>
>

<?php }?>

<?php echo '<script'; ?>
>
		function getQueryVariable(variable)
	{
	       var query = window.location.search.substring(1);
	       var vars = query.split("&");
	       for (var i=0;i<vars.length;i++) {
	            	var pair = vars[i].split("=");
	            	if(pair[0] == variable){
	            		return pair[1];
	            	}
	       }
	       return "";
	}

		function setCookie(cname,cvalue,exdays)
	{
	  var d = new Date();
	  d.setTime(d.getTime()+(exdays*24*60*60*1000));
	  var expires = "expires="+d.toGMTString();
	  document.cookie = cname + "=" + cvalue + "; " + expires;
	}

		function getCookie(cname)
	{
	  var name = cname + "=";
	  var ca = document.cookie.split(';');
	  for(var i=0; i<ca.length; i++) 
	  {
	    var c = ca[i].trim();
	    if (c.indexOf(name)==0) return c.substring(name.length,c.length);
	  }
	  return "";
	}

		if (getQueryVariable('code')!=''){
		setCookie('code',getQueryVariable('code'),30);
		window.location.href='/auth/register'; 
	}

    <?php if ($_smarty_tpl->tpl_vars['config']->value['register_mode'] == 'invite') {?>
		if ((getCookie('code'))!=''){
		$("#code").val(getCookie('code'));
	}
	<?php }?>


<?php echo '</script'; ?>
>
<?php if ($_smarty_tpl->tpl_vars['recaptcha_sitekey']->value != null) {
echo '<script'; ?>
 src="https://recaptcha.net/recaptcha/api.js" async defer><?php echo '</script'; ?>
><?php }
}
}
